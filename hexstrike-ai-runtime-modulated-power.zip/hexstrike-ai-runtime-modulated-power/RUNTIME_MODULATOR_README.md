# HexStrike Local LLM Real-Time Runtime Modulator

This add-on is intentionally **not** a second HexStrike AI brain.

HexStrike remains the main planner/orchestrator. This layer only adds the missing runtime capability:

```text
running tool output -> structured event -> local LLM decision -> hard policy guard -> continue/stop/reduce/restart/follow-up/save evidence
```

## Files added/changed

### Added

- `hexstrike_runtime_modulator.py`
  - Local LLM decision client for Ollama
  - Safety/scope policy
  - Streaming tool runner
  - Live event parser
  - Runtime action enforcement
  - Evidence/event JSONL storage

### Changed

- `hexstrike_server.py`
  - Imports the runtime modulator
  - Adds `POST /api/tools/modulated-web-scan`
  - Adds `GET /api/runtime-modulator/health`

- `hexstrike_mcp.py`
  - Adds MCP tool `modulated_web_scan(...)`

## What it does in real time

While tools are still running, it can:

- Continue
- Stop a noisy tool
- Reduce rate by terminating and restarting with lower rate
- Restart focused with narrower scope
- Launch a bounded follow-up job
- Save evidence immediately
- Mark noisy output

## Why this is real-time modulation

Existing HexStrike tool calls normally follow this pattern:

```text
AI chooses tool -> tool runs -> final result returned -> AI decides next step
```

This add-on changes the runtime pattern to:

```text
tool starts -> every stdout/stderr line is parsed -> local LLM decides -> safety validates -> action happens while scan is active
```

For CLI tools that do not expose a live control API, true internal parameter changes are not possible. The modulator handles that by safely terminating/restarting the process with new parameters or launching focused follow-up jobs while the original job is still active.

## Required environment

Run a local model with Ollama:

```bash
ollama pull qwen2.5-coder:7b
```

Optional environment variables:

```bash
export HEXSTRIKE_MODULATOR_MODEL=qwen2.5-coder:7b
export OLLAMA_URL=http://127.0.0.1:11434/api/chat
export HEXSTRIKE_ALLOWED_HOSTS=staging.example.com,api-staging.example.com
export HEXSTRIKE_MODULATOR_MAX_RPS=5
export HEXSTRIKE_MODULATOR_MAX_JOBS=12
export HEXSTRIKE_MODULATOR_MAX_RUNTIME=900
```

For testing without Ollama, use the built-in safe rule fallback:

```bash
export HEXSTRIKE_DISABLE_LOCAL_LLM=true
```

## Start HexStrike server

```bash
python3 hexstrike_server.py
```

Health check:

```bash
curl http://127.0.0.1:8888/api/runtime-modulator/health
```

## Run through REST API

```bash
curl -X POST http://127.0.0.1:8888/api/tools/modulated-web-scan \
  -H 'Content-Type: application/json' \
  -d '{
    "target": "https://staging.example.com",
    "profile": "web_mvp",
    "options": {
      "allowed_hosts": ["staging.example.com"],
      "rate_limit_rps": 2,
      "max_jobs": 12,
      "max_runtime_seconds": 900,
      "wordlist": "/usr/share/wordlists/dirb/common.txt"
    }
  }'
```

## Run through MCP

Use the new MCP tool:

```text
modulated_web_scan(
  target="https://staging.example.com",
  allowed_hosts="staging.example.com",
  max_jobs=12,
  max_runtime_seconds=900,
  rate_limit_rps=2
)
```

## Safety boundaries

The modulator blocks:

- Out-of-scope hosts
- Blocked hosts
- Blocked paths like `/payment`, `/charge`, `/send-email`, `/send-sms`, `/delete-account`, `/webhook/live`
- Tools outside the web-safe allow-list
- Rates above the configured maximum

The LLM is allowed to decide, but the policy guard has final authority.

## Evidence output

Each run writes JSONL files under `runtime_modulator_data/`:

- `<run_id>_events.jsonl`
- `<run_id>_decisions.jsonl`
- `<run_id>_findings.jsonl`

The API response includes the file paths and a compact summary for HexStrike's main brain.
