# HexStrike Local LLM Runtime Modulator - Power Safe Edition

This build strengthens the runtime modulation layer while keeping HexStrike's main AI plugin as the main brain.

## What is stronger now

- **Local LLM required mode**: set `require_local_llm=true` or `HEXSTRIKE_REQUIRE_LOCAL_LLM=true`; scans are blocked/stopped if Ollama is unavailable.
- **Live JSON-aware event parsing** for `httpx -json` and `nuclei -jsonl`, plus text parsing for `katana`, `ffuf`, `arjun`, `whatweb`, ZAP baseline, TLS tools, and others.
- **Risk scoring** for live events based on server errors, admin/internal paths, API routes, GraphQL, file upload, risky parameters, sensitive hints, and tool findings.
- **Adaptive follow-up queue**: the local LLM can decide `continue`, `stop_tool`, `reduce_rate`, `restart_focused`, `launch_followup`, `compare_roles`, `api_validate`, `save_evidence`, or `mark_noise`.
- **Role comparison worker**: uses supplied test `headers`/`cookies` to compare access across roles using safe GET requests only.
- **Safe API validation worker**: uses HEAD/OPTIONS/GET-only probes and harmless query parameters; no POST/PATCH/DELETE destructive actions.
- **Adaptive app wordlist**: discovered path segments are saved into a per-run wordlist and reused for focused ffuf restarts.
- **Stop conditions**: stops when too many 5xx/server-error events appear.
- **Safer nuclei defaults**: excludes intrusive, DoS, fuzz, brute force, and default-login tagged templates.
- **Better health endpoint**: `/api/runtime-modulator/health` now returns local LLM availability and blocked capabilities.

## Still intentionally blocked

This build does not add credential attacks, brute force, stealth, WAF bypass, destructive testing, exploit-chain execution, data exfiltration, persistence, or lateral movement.

## Run with local LLM required

```bash
ollama pull qwen2.5-coder:7b
export HEXSTRIKE_MODULATOR_MODEL=qwen2.5-coder:7b
export HEXSTRIKE_REQUIRE_LOCAL_LLM=true
export HEXSTRIKE_ALLOWED_HOSTS=staging.example.com,api-staging.example.com
python3 hexstrike_server.py
```

## API call

```bash
curl -X POST http://127.0.0.1:8888/api/tools/modulated-web-scan \
  -H 'Content-Type: application/json' \
  -d '{
    "target": "https://staging.example.com",
    "profile": "web_power",
    "options": {
      "allowed_hosts": ["staging.example.com"],
      "require_local_llm": true,
      "rate_limit_rps": 2,
      "max_jobs": 24,
      "max_runtime_seconds": 1200,
      "role_contexts": [
        {"name": "anonymous", "headers": {}},
        {"name": "customer_a", "headers": {"Authorization": "Bearer TEST_TOKEN_A"}},
        {"name": "customer_b", "headers": {"Authorization": "Bearer TEST_TOKEN_B"}}
      ]
    }
  }'
```

Use only test tokens/accounts created for your authorised staging/owned website.

## MCP call

```text
modulated_web_scan(
  target="https://staging.example.com",
  profile="web_power",
  allowed_hosts="staging.example.com",
  require_local_llm=True,
  max_jobs=24,
  max_runtime_seconds=1200,
  rate_limit_rps=2,
  role_contexts_json='[{"name":"anonymous","headers":{}},{"name":"customer_a","headers":{"Authorization":"Bearer TEST_TOKEN_A"}},{"name":"customer_b","headers":{"Authorization":"Bearer TEST_TOKEN_B"}}]'
)
```

## Evidence output

Each run writes:

- `runtime_modulator_data/<run_id>_events.jsonl`
- `runtime_modulator_data/<run_id>_decisions.jsonl`
- `runtime_modulator_data/<run_id>_findings.jsonl`
- `runtime_modulator_data/<run_id>_adaptive_wordlist.txt`

These files show the live event, the local LLM decision, policy validation, and evidence captured.
