#!/usr/bin/env python3
"""
HexStrike Runtime Modulator - Power Safe Edition

Purpose:
    Add LOCAL LLM real-time tool modulation without replacing HexStrike's main AI brain.

This layer is intentionally a runtime control plane, not a second global pentest brain.
It streams live tool output, turns it into structured events, asks a local LLM for
small runtime control decisions, validates those decisions against hard policy, and
then continues/stops/restarts/retunes/launches safe follow-ups.

Allowed focus:
    - Authorised websites owned by the user or explicitly in scope.
    - Non-destructive web/API discovery, validation, evidence capture, and reporting.
    - Role/access-control comparison using supplied test auth contexts only.

Intentionally blocked:
    - Credential attacks, brute force, stealth, WAF bypass, destructive testing.
    - Exploit-chain execution, persistence, lateral movement, data exfiltration.
"""

from __future__ import annotations

import hashlib
import json
import os
import queue
import re
import signal
import subprocess
import threading
import time
import uuid
from collections import Counter, defaultdict
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

try:
    import requests
except Exception:  # pragma: no cover - HexStrike normally has requests
    requests = None


URL_RE = re.compile(r"https?://[^\s'\"<>]+", re.IGNORECASE)
STATUS_RE = re.compile(r"\b(10[0-3]|20[0-8]|30[0-8]|40[0-9]|41[0-8]|42[0-9]|43[0-1]|45[0-1]|50[0-8])\b")
PARAM_RISK_RE = re.compile(r"\b(userId|user_id|accountId|account_id|tenantId|tenant_id|orderId|order_id|invoiceId|invoice_id|role|status|redirect|redirect_uri|callback|returnUrl|file|filename|path|url|next)\b", re.I)
SENSITIVE_RE = re.compile(r"\b(password|secret|token|api[_-]?key|private[_-]?key|ssn|credit[_-]?card|authorization|bearer|set-cookie)\b", re.I)


@dataclass
class RuntimeTask:
    tool: str
    target: str
    reason: str = "initial"
    rate_limit_rps: int = 2
    wordlist: str = ""
    depth: int = 2
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RuntimePolicy:
    allowed_hosts: Set[str]
    blocked_hosts: Set[str] = field(default_factory=set)
    blocked_path_prefixes: Tuple[str, ...] = (
        "/payment",
        "/charge",
        "/checkout/charge",
        "/send-email",
        "/send-sms",
        "/delete-account",
        "/webhook/live",
        "/admin/destructive",
    )
    allowed_tools: Set[str] = field(default_factory=lambda: {
        "katana", "httpx", "ffuf", "nuclei", "zap", "arjun", "dalfox",
        "whatweb", "testssl", "sslscan", "role_compare", "api_validate"
    })
    max_rps: int = 5
    default_rps: int = 2
    max_jobs: int = 24
    max_runtime_seconds: int = 1200
    max_events_per_job: int = 400
    max_5xx_events: int = 15
    require_local_llm: bool = False

    @classmethod
    def from_request(cls, target: str, options: Optional[Dict[str, Any]] = None) -> "RuntimePolicy":
        options = options or {}
        parsed = urlparse(target)
        target_host = parsed.hostname or target

        env_hosts = os.environ.get("HEXSTRIKE_ALLOWED_HOSTS", "")
        request_hosts = options.get("allowed_hosts") or []
        allowed_hosts = {target_host}
        allowed_hosts.update(h.strip() for h in env_hosts.split(",") if h.strip())
        allowed_hosts.update(str(h).strip() for h in request_hosts if str(h).strip())

        blocked_hosts = set(options.get("blocked_hosts") or [])
        blocked_env = os.environ.get("HEXSTRIKE_BLOCKED_HOSTS", "")
        blocked_hosts.update(h.strip() for h in blocked_env.split(",") if h.strip())

        blocked_paths = tuple(options.get("blocked_paths") or cls.blocked_path_prefixes)
        allowed_tools = set(options.get("allowed_tools") or {
            "katana", "httpx", "ffuf", "nuclei", "zap", "arjun", "dalfox",
            "whatweb", "testssl", "sslscan", "role_compare", "api_validate"
        })

        return cls(
            allowed_hosts=allowed_hosts,
            blocked_hosts=blocked_hosts,
            blocked_path_prefixes=blocked_paths,
            allowed_tools=allowed_tools,
            max_rps=int(options.get("max_rps", os.environ.get("HEXSTRIKE_MODULATOR_MAX_RPS", 5))),
            default_rps=int(options.get("default_rps", options.get("rate_limit_rps", os.environ.get("HEXSTRIKE_MODULATOR_DEFAULT_RPS", 2)))),
            max_jobs=int(options.get("max_jobs", os.environ.get("HEXSTRIKE_MODULATOR_MAX_JOBS", 24))),
            max_runtime_seconds=int(options.get("max_runtime_seconds", os.environ.get("HEXSTRIKE_MODULATOR_MAX_RUNTIME", 1200))),
            max_events_per_job=int(options.get("max_events_per_job", os.environ.get("HEXSTRIKE_MODULATOR_MAX_EVENTS_PER_JOB", 400))),
            max_5xx_events=int(options.get("max_5xx_events", os.environ.get("HEXSTRIKE_MODULATOR_MAX_5XX", 15))),
            require_local_llm=str(options.get("require_local_llm", os.environ.get("HEXSTRIKE_REQUIRE_LOCAL_LLM", "false"))).lower() == "true",
        )

    def target_in_scope(self, target: str) -> bool:
        parsed = urlparse(target)
        host = parsed.hostname
        path = parsed.path or "/"
        scheme = parsed.scheme

        if not host or scheme not in {"http", "https"}:
            return False
        if host in self.blocked_hosts:
            return False
        if host not in self.allowed_hosts:
            return False
        if any(path.startswith(prefix) for prefix in self.blocked_path_prefixes):
            return False
        return True

    def validate_decision(self, decision: Dict[str, Any]) -> Tuple[bool, str]:
        allowed_actions = {
            "continue", "stop_tool", "reduce_rate", "restart_focused", "launch_followup",
            "save_evidence", "mark_noise", "compare_roles", "api_validate"
        }
        action = decision.get("action", "continue")
        tool = decision.get("tool")
        target = decision.get("target")
        try:
            rps = int(decision.get("rate_limit_rps") or self.default_rps)
        except Exception:
            rps = self.default_rps

        if action not in allowed_actions:
            return False, f"action_not_allowed:{action}"
        if tool and tool not in self.allowed_tools:
            return False, f"tool_not_allowed:{tool}"
        if target and not self.target_in_scope(target):
            return False, f"target_out_of_scope:{target}"
        if rps > self.max_rps:
            return False, f"rate_too_high:{rps}"
        return True, "ok"


@dataclass
class ScanContext:
    run_id: str
    target: str
    profile: str
    policy: RuntimePolicy
    options: Dict[str, Any] = field(default_factory=dict)
    role_contexts: List[Dict[str, Any]] = field(default_factory=list)
    started_at: float = field(default_factory=time.time)
    events: List[Dict[str, Any]] = field(default_factory=list)
    decisions: List[Dict[str, Any]] = field(default_factory=list)
    findings: List[Dict[str, Any]] = field(default_factory=list)
    jobs_started: int = 0
    stopped_jobs: int = 0
    followups_started: int = 0
    server_error_events: int = 0
    stop_requested: bool = False
    seen_tasks: Set[Tuple[str, str, str]] = field(default_factory=set)
    discovered_segments: Counter = field(default_factory=Counter)
    discovered_params: Counter = field(default_factory=Counter)
    risk_counter: Counter = field(default_factory=Counter)
    endpoint_kind_counter: Counter = field(default_factory=Counter)
    lock: threading.RLock = field(default_factory=threading.RLock)
    executor: Optional[ThreadPoolExecutor] = None
    futures: Set[Any] = field(default_factory=set)

    def expired(self) -> bool:
        return self.stop_requested or (time.time() - self.started_at) > self.policy.max_runtime_seconds


class LocalLLMDecisionClient:
    """Small local LLM client. The model only makes runtime control decisions."""

    def __init__(self) -> None:
        self.url = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
        self.model = os.environ.get("HEXSTRIKE_MODULATOR_MODEL", "qwen2.5-coder:7b")
        self.timeout = int(os.environ.get("HEXSTRIKE_MODULATOR_LLM_TIMEOUT", "30"))
        self.enabled = os.environ.get("HEXSTRIKE_DISABLE_LOCAL_LLM", "false").lower() != "true"

    def health(self) -> Dict[str, Any]:
        if not self.enabled:
            return {"enabled": False, "available": False, "reason": "HEXSTRIKE_DISABLE_LOCAL_LLM=true"}
        if requests is None:
            return {"enabled": True, "available": False, "reason": "requests module unavailable"}
        probe = {
            "model": self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": "Return JSON only."},
                {"role": "user", "content": "{\"ping\":true}"},
            ],
            "options": {"temperature": 0},
        }
        try:
            response = requests.post(self.url, json=probe, timeout=min(8, self.timeout))
            response.raise_for_status()
            return {"enabled": True, "available": True, "model": self.model, "url": self.url}
        except Exception as exc:
            return {"enabled": True, "available": False, "model": self.model, "url": self.url, "reason": str(exc)}

    def decide(self, event: Dict[str, Any], require_local_llm: bool = False) -> Dict[str, Any]:
        if not self.enabled or requests is None:
            if require_local_llm:
                return self._llm_unavailable_decision("Local LLM disabled or requests unavailable", event)
            return self.rule_based_decision(event)

        system_prompt = """
You are a LOCAL defensive runtime controller for authorised web security testing.
You are NOT the main pentest brain. HexStrike already handles global planning.
You only make small live runtime decisions from one tool event.

Allowed actions only:
continue, stop_tool, reduce_rate, restart_focused, launch_followup, save_evidence,
mark_noise, compare_roles, api_validate.

Allowed tools only:
katana, httpx, ffuf, nuclei, zap, arjun, dalfox, whatweb, testssl, sslscan,
role_compare, api_validate.

Rules:
- Prefer role_compare for admin/API/id-like endpoints when role_contexts_available=true.
- Prefer api_validate for GET-safe API endpoints with risky params.
- Prefer save_evidence for server errors, suspicious auth/session hints, sensitive headers,
  exposed admin paths, GraphQL endpoints, or high-confidence tool findings.
- Prefer reduce_rate or stop_tool when many 5xx/rate-limit/availability signals appear.
- Use launch_followup for safe focused tools only.

Never request: credential attacks, brute force, stealth, WAF bypass, destructive actions,
production testing, persistence, lateral movement, data extraction, exploit execution,
or attempts to bypass protections.

Return strict JSON only with keys:
action, tool, target, reason, priority, rate_limit_rps.
""".strip()

        user_prompt = json.dumps({"live_event": event}, indent=2)
        payload = {
            "model": self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "options": {"temperature": 0.1},
        }

        try:
            response = requests.post(self.url, json=payload, timeout=self.timeout)
            response.raise_for_status()
            content = response.json().get("message", {}).get("content", "")
            return self._parse_json_or_fallback(content, event, require_local_llm)
        except Exception as exc:
            if require_local_llm:
                return self._llm_unavailable_decision(str(exc), event)
            return self.rule_based_decision(event)

    def _llm_unavailable_decision(self, reason: str, event: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "action": "stop_tool",
            "tool": event.get("tool"),
            "target": event.get("url") or event.get("target"),
            "reason": f"Local LLM is required but unavailable: {reason}",
            "priority": "critical",
            "rate_limit_rps": 1,
        }

    def _parse_json_or_fallback(self, content: str, event: Dict[str, Any], require_local_llm: bool) -> Dict[str, Any]:
        try:
            parsed = json.loads(content)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
        match = re.search(r"\{.*\}", content, re.DOTALL)
        if match:
            try:
                parsed = json.loads(match.group(0))
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
        if require_local_llm:
            return self._llm_unavailable_decision("Local LLM returned invalid JSON", event)
        return self.rule_based_decision(event)

    def rule_based_decision(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """Safe fallback if Ollama is unavailable and require_local_llm is false."""
        target = event.get("url") or event.get("target")
        hint = event.get("risk_hint", "")
        status = int(event.get("status") or 0)
        tool = event.get("tool", "")
        risk_score = int(event.get("risk_score") or 0)
        role_contexts_available = bool(event.get("role_contexts_available"))

        if status >= 500 or hint == "server_error":
            return {
                "action": "reduce_rate",
                "tool": tool,
                "target": target,
                "reason": "Server error observed in live output; reduce scan pressure.",
                "priority": "high",
                "rate_limit_rps": 1,
            }

        if role_contexts_available and hint in {"admin_path", "api_path", "idor_candidate"} and target:
            return {
                "action": "compare_roles",
                "tool": "role_compare",
                "target": target,
                "reason": "High-value endpoint discovered; compare supplied test roles safely.",
                "priority": "high",
                "rate_limit_rps": 1,
            }

        if hint in {"api_path", "graphql_endpoint", "risky_parameter"} and target:
            return {
                "action": "api_validate",
                "tool": "api_validate",
                "target": target,
                "reason": f"Safe API validation candidate from live event: {hint}.",
                "priority": "medium",
                "rate_limit_rps": 1,
            }

        if hint in {"admin_path", "upload_endpoint", "graphql_endpoint", "sensitive_hint", "tool_finding"} and target:
            return {
                "action": "save_evidence",
                "tool": tool,
                "target": target,
                "reason": f"Evidence-worthy runtime event: {hint}.",
                "priority": "medium" if risk_score < 80 else "high",
                "rate_limit_rps": 1,
            }

        if hint in {"admin_path", "api_path", "upload_endpoint", "graphql_endpoint"} and target:
            followup_tool = "nuclei" if tool != "nuclei" else "httpx"
            return {
                "action": "launch_followup",
                "tool": followup_tool,
                "target": target,
                "reason": f"Live event indicates high-value web area: {hint}.",
                "priority": "medium",
                "rate_limit_rps": 1,
            }

        return {
            "action": "continue",
            "tool": tool,
            "target": target,
            "reason": "No runtime change needed.",
            "priority": "low",
            "rate_limit_rps": 1,
        }


class HexStrikeRuntimeModulator:
    def __init__(self) -> None:
        self.llm = LocalLLMDecisionClient()
        self.data_dir = Path(os.environ.get("HEXSTRIKE_MODULATOR_DATA_DIR", "runtime_modulator_data"))
        self.data_dir.mkdir(exist_ok=True)

    def health(self) -> Dict[str, Any]:
        return {
            "component": "hexstrike-runtime-modulator-power-safe",
            "purpose": "local_llm_realtime_tool_modulation",
            "local_llm": self.llm.health(),
            "data_dir": str(self.data_dir),
            "blocked_capabilities": sorted(AuthorizedPentestPlanner.BLOCKED_CAPABILITIES),
        }

    def run_modulated_web_scan(self, target: str, profile: str = "web_power", options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        options = options or {}
        policy = RuntimePolicy.from_request(target, options)

        if not policy.target_in_scope(target):
            return {
                "success": False,
                "status": "blocked",
                "reason": "Target is outside approved modulator scope",
                "target": target,
                "allowed_hosts": sorted(policy.allowed_hosts),
            }

        if policy.require_local_llm:
            llm_health = self.llm.health()
            if not llm_health.get("available"):
                return {
                    "success": False,
                    "status": "blocked",
                    "reason": "require_local_llm=true but local LLM is unavailable",
                    "local_llm": llm_health,
                }

        ctx = ScanContext(
            run_id=f"rtm_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}",
            target=target,
            profile=profile,
            policy=policy,
            options=options,
            role_contexts=self._normalise_role_contexts(options.get("role_contexts") or []),
        )

        initial_tasks = self._initial_tasks(target, profile, policy, options)

        with ThreadPoolExecutor(max_workers=int(options.get("max_workers", 5))) as executor:
            ctx.executor = executor
            for task in initial_tasks:
                self._submit_task(ctx, task)

            while ctx.futures and not ctx.expired():
                done, _ = wait(ctx.futures, timeout=1.0, return_when=FIRST_COMPLETED)
                for future in done:
                    ctx.futures.discard(future)

        return self._summary(ctx)

    def _normalise_role_contexts(self, raw: Any) -> List[Dict[str, Any]]:
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except Exception:
                raw = []
        if not isinstance(raw, list):
            return []
        normalised = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or item.get("role") or f"role_{len(normalised)+1}")
            headers = item.get("headers") or {}
            cookies = item.get("cookies") or {}
            expected_private = bool(item.get("expected_private", True))
            if isinstance(headers, dict) and isinstance(cookies, dict):
                normalised.append({
                    "name": name,
                    "headers": {str(k): str(v) for k, v in headers.items()},
                    "cookies": {str(k): str(v) for k, v in cookies.items()},
                    "expected_private": expected_private,
                })
        return normalised[:6]

    def _initial_tasks(self, target: str, profile: str, policy: RuntimePolicy, options: Dict[str, Any]) -> List[RuntimeTask]:
        wordlist = options.get("wordlist") or os.environ.get("HEXSTRIKE_MODULATOR_WORDLIST") or "/usr/share/wordlists/dirb/common.txt"
        depth = int(options.get("depth", 2))
        rps = min(int(options.get("rate_limit_rps", policy.default_rps)), policy.max_rps)
        profile = profile or "web_power"

        base = [
            RuntimeTask("katana", target, "initial_crawl", rps, wordlist, depth),
            RuntimeTask("httpx", target, "initial_probe", rps, wordlist, depth),
            RuntimeTask("ffuf", target, "initial_content_discovery", rps, wordlist, depth),
            RuntimeTask("nuclei", target, "initial_safe_template_checks", rps, wordlist, depth),
        ]
        if profile in {"web_power", "owned_web_full", "deep_web_safe"}:
            base.extend([
                RuntimeTask("whatweb", target, "technology_fingerprint", rps, wordlist, depth),
                RuntimeTask("arjun", target, "safe_parameter_discovery", rps, wordlist, depth),
                RuntimeTask("zap", target, "baseline_passive_dast", rps, wordlist, depth),
            ])
        if profile in {"deep_web_safe", "tls_web_safe"}:
            base.append(RuntimeTask("testssl", target, "tls_configuration_review", 1, wordlist, depth))
        return [t for t in base if t.tool in policy.allowed_tools]

    def _submit_task(self, ctx: ScanContext, task: RuntimeTask) -> None:
        with ctx.lock:
            if ctx.jobs_started >= ctx.policy.max_jobs or ctx.expired():
                return
            if task.tool not in ctx.policy.allowed_tools:
                return
            if not ctx.policy.target_in_scope(task.target):
                return
            task_key = (task.tool, task.target, json.dumps(task.metadata, sort_keys=True, default=str)[:120])
            if task_key in ctx.seen_tasks:
                return

            ctx.seen_tasks.add(task_key)
            ctx.jobs_started += 1
            future = ctx.executor.submit(self._run_tool_streaming, ctx, task)  # type: ignore[union-attr]
            ctx.futures.add(future)

    def _run_tool_streaming(self, ctx: ScanContext, task: RuntimeTask) -> None:
        if task.tool == "role_compare":
            self._run_role_compare(ctx, task)
            return
        if task.tool == "api_validate":
            self._run_api_validate(ctx, task)
            return

        command = self._build_command(task, ctx.policy)
        if not command:
            self._record_event(ctx, {
                "type": "tool_not_available_or_not_supported",
                "tool": task.tool,
                "target": task.target,
                "timestamp": datetime.utcnow().isoformat(),
            })
            return

        process = None
        event_count = 0
        started = time.time()

        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True,
                preexec_fn=os.setsid if os.name != "nt" else None,
            )

            self._record_event(ctx, {
                "type": "job_started",
                "tool": task.tool,
                "target": task.target,
                "pid": process.pid,
                "command_preview": self._safe_command_preview(command),
                "reason": task.reason,
                "timestamp": datetime.utcnow().isoformat(),
            })

            assert process.stdout is not None
            for raw_line in iter(process.stdout.readline, ""):
                if not raw_line:
                    break
                if ctx.expired():
                    self._terminate(process)
                    break

                line = raw_line.strip()
                if not line:
                    continue

                event_count += 1
                event = self._parse_event(ctx, task, line)
                self._record_event(ctx, event)

                decision = self.llm.decide(event, require_local_llm=ctx.policy.require_local_llm)
                valid, reason = ctx.policy.validate_decision(decision)
                decision_record = {
                    "type": "llm_runtime_decision",
                    "valid": valid,
                    "policy_reason": reason,
                    "event": event,
                    "decision": decision,
                    "timestamp": datetime.utcnow().isoformat(),
                }
                self._record_decision(ctx, decision_record)

                if valid:
                    self._apply_decision(ctx, task, process, decision)

                if event_count >= ctx.policy.max_events_per_job or ctx.stop_requested:
                    self._terminate(process)
                    break

            try:
                return_code = process.wait(timeout=5)
            except Exception:
                self._terminate(process)
                return_code = -1
            self._record_event(ctx, {
                "type": "job_finished",
                "tool": task.tool,
                "target": task.target,
                "return_code": return_code,
                "duration_seconds": round(time.time() - started, 2),
                "timestamp": datetime.utcnow().isoformat(),
            })
        except FileNotFoundError:
            self._record_event(ctx, {
                "type": "tool_binary_missing",
                "tool": task.tool,
                "target": task.target,
                "command_preview": self._safe_command_preview(command),
                "timestamp": datetime.utcnow().isoformat(),
            })
        except Exception as exc:
            if process and process.poll() is None:
                self._terminate(process)
            self._record_event(ctx, {
                "type": "job_error",
                "tool": task.tool,
                "target": task.target,
                "error": str(exc),
                "timestamp": datetime.utcnow().isoformat(),
            })

    def _build_command(self, task: RuntimeTask, policy: RuntimePolicy) -> Optional[List[str]]:
        rps = str(max(1, min(task.rate_limit_rps, policy.max_rps)))
        target = task.target

        if task.tool == "katana":
            return ["katana", "-u", target, "-d", str(max(1, min(task.depth, 3))), "-silent"]

        if task.tool == "httpx":
            return ["httpx", "-u", target, "-silent", "-json", "-status-code", "-title", "-tech-detect", "-follow-redirects"]

        if task.tool == "ffuf":
            fuzz_url = target.rstrip("/") + "/FUZZ"
            return ["ffuf", "-u", fuzz_url, "-w", task.wordlist, "-rate", rps, "-mc", "200,204,301,302,307,401,403", "-timeout", "10"]

        if task.tool == "nuclei":
            # Exclude noisy/intrusive categories by default. This remains non-destructive and bounded.
            return [
                "nuclei", "-u", target,
                "-severity", "low,medium,high,critical",
                "-exclude-tags", "intrusive,dos,fuzz,bruteforce,default-login",
                "-rate-limit", rps,
                "-jsonl",
                "-silent",
            ]

        if task.tool == "arjun":
            return ["arjun", "-u", target, "--stable", "-q"]

        if task.tool == "dalfox":
            # Safe bounded XSS-oriented validation on discovered parameters only.
            return ["dalfox", "url", target, "--silence", "--timeout", "10", "--skip-bav"]

        if task.tool == "zap":
            # Baseline scan is passive/non-destructive by design.
            return ["zap-baseline.py", "-t", target, "-m", "3", "-J", str(self.data_dir / f"zap_{uuid.uuid4().hex[:8]}.json")]

        if task.tool == "whatweb":
            return ["whatweb", "--no-errors", "--color=never", target]

        if task.tool == "testssl":
            return ["testssl.sh", "--fast", "--warnings", "off", target]

        if task.tool == "sslscan":
            parsed = urlparse(target)
            host = parsed.hostname or target
            return ["sslscan", host]

        return None

    def _parse_event(self, ctx: ScanContext, task: RuntimeTask, line: str) -> Dict[str, Any]:
        json_obj = self._try_parse_json(line)
        if json_obj:
            event = self._parse_json_event(task, json_obj, line)
        else:
            event = self._parse_text_event(task, line)

        event["role_contexts_available"] = len(ctx.role_contexts) >= 2
        event["require_local_llm"] = ctx.policy.require_local_llm
        event["blocked_capabilities"] = sorted(AuthorizedPentestPlanner.BLOCKED_CAPABILITIES)
        self._enrich_event(event)
        self._update_discovery_state(ctx, event)
        return event

    def _try_parse_json(self, line: str) -> Optional[Dict[str, Any]]:
        if not line or not line.lstrip().startswith("{"):
            return None
        try:
            parsed = json.loads(line)
            return parsed if isinstance(parsed, dict) else None
        except Exception:
            return None

    def _parse_json_event(self, task: RuntimeTask, obj: Dict[str, Any], raw: str) -> Dict[str, Any]:
        target_url = obj.get("url") or obj.get("matched-at") or obj.get("host") or obj.get("input") or task.target
        status = obj.get("status-code") or obj.get("status") or obj.get("response-status-code")
        try:
            status = int(status) if status is not None else None
        except Exception:
            status = None
        severity = None
        template_id = obj.get("template-id")
        if isinstance(obj.get("info"), dict):
            severity = obj["info"].get("severity")
        tech = obj.get("tech") or obj.get("technologies") or []
        title = obj.get("title")
        return {
            "type": "tool_output_event",
            "tool": task.tool,
            "target": task.target,
            "url": str(target_url),
            "status": status,
            "template_id": template_id,
            "severity": severity,
            "title": title,
            "tech": tech,
            "raw": raw[:1000],
            "timestamp": datetime.utcnow().isoformat(),
        }

    def _parse_text_event(self, task: RuntimeTask, line: str) -> Dict[str, Any]:
        urls = URL_RE.findall(line)
        target_url = urls[0].rstrip(",);]") if urls else task.target
        status_match = STATUS_RE.search(line)
        status = int(status_match.group(1)) if status_match else None
        return {
            "type": "tool_output_event",
            "tool": task.tool,
            "target": task.target,
            "url": target_url,
            "status": status,
            "raw": line[:1000],
            "timestamp": datetime.utcnow().isoformat(),
        }

    def _enrich_event(self, event: Dict[str, Any]) -> None:
        url = str(event.get("url") or event.get("target") or "")
        raw = str(event.get("raw") or "")
        lower = (url + " " + raw).lower()
        parsed = urlparse(url)
        path = parsed.path or "/"
        params = [k for k, _ in parse_qsl(parsed.query, keep_blank_values=True)]
        endpoint_kind = "page"
        risk_hint = "generic_output"
        score = 0
        tags: List[str] = []

        status = event.get("status")
        try:
            status_int = int(status) if status is not None else 0
        except Exception:
            status_int = 0

        if status_int >= 500 or "internal server error" in lower or "stack trace" in lower or "traceback" in lower:
            risk_hint = "server_error"
            score += 90
            tags.append("server_error")
        if "/api/" in lower or lower.endswith("/api"):
            endpoint_kind = "api"
            risk_hint = "api_path" if risk_hint == "generic_output" else risk_hint
            score += 35
            tags.append("api")
        if "graphql" in lower:
            endpoint_kind = "graphql"
            risk_hint = "graphql_endpoint"
            score += 55
            tags.append("graphql")
        if "admin" in lower or "/manage" in lower or "/internal" in lower:
            endpoint_kind = "admin_or_internal"
            risk_hint = "admin_path"
            score += 60
            tags.append("admin_or_internal")
        if "upload" in lower or "multipart" in lower:
            endpoint_kind = "upload"
            risk_hint = "upload_endpoint"
            score += 55
            tags.append("upload")
        if PARAM_RISK_RE.search(url) or any(PARAM_RISK_RE.search(p or "") for p in params):
            risk_hint = "risky_parameter" if risk_hint == "generic_output" else "idor_candidate"
            score += 55
            tags.append("risky_parameter")
        if SENSITIVE_RE.search(raw):
            risk_hint = "sensitive_hint"
            score += 80
            tags.append("sensitive_hint")
        if event.get("template_id") or event.get("severity"):
            risk_hint = "tool_finding"
            severity = str(event.get("severity") or "").lower()
            score += {"info": 10, "low": 25, "medium": 55, "high": 80, "critical": 95}.get(severity, 40)
            tags.append("tool_finding")
        if status_int in {401, 403}:
            score += 15
            tags.append("auth_boundary")
        if status_int in {200, 204} and ("admin" in lower or "/api/" in lower):
            score += 20
            tags.append("accessible_high_value")

        event["risk_hint"] = risk_hint
        event["risk_score"] = min(score, 100)
        event["endpoint_kind"] = endpoint_kind
        event["path"] = path
        event["params"] = params[:20]
        event["evidence_tags"] = sorted(set(tags))

    def _update_discovery_state(self, ctx: ScanContext, event: Dict[str, Any]) -> None:
        parsed = urlparse(str(event.get("url") or ""))
        with ctx.lock:
            for segment in [s for s in parsed.path.split("/") if s and len(s) <= 40]:
                ctx.discovered_segments[segment] += 1
            for p in event.get("params") or []:
                ctx.discovered_params[p] += 1
            if event.get("risk_hint"):
                ctx.risk_counter[event["risk_hint"]] += 1
            if event.get("endpoint_kind"):
                ctx.endpoint_kind_counter[event["endpoint_kind"]] += 1

    def _apply_decision(self, ctx: ScanContext, task: RuntimeTask, process: subprocess.Popen, decision: Dict[str, Any]) -> None:
        action = decision.get("action", "continue")
        target = decision.get("target") or task.target
        tool = decision.get("tool") or task.tool
        reason = decision.get("reason", "runtime_decision")
        try:
            rps = int(decision.get("rate_limit_rps") or task.rate_limit_rps or ctx.policy.default_rps)
        except Exception:
            rps = ctx.policy.default_rps
        rps = max(1, min(rps, ctx.policy.max_rps))

        if action in {"continue", "mark_noise"}:
            return

        if action == "save_evidence":
            self._save_evidence(ctx, task.tool, target, reason, decision.get("priority", "medium"), decision)
            return

        if action in {"stop_tool", "reduce_rate", "restart_focused"}:
            self._terminate(process)
            with ctx.lock:
                ctx.stopped_jobs += 1

        if action in {"reduce_rate", "restart_focused"}:
            self._submit_task(ctx, RuntimeTask(
                tool=task.tool,
                target=target,
                reason=f"{action}:{reason}",
                rate_limit_rps=1 if action == "reduce_rate" else rps,
                wordlist=self._wordlist_for_context(ctx, task.wordlist),
                depth=max(1, task.depth - 1),
            ))
            return

        if action == "launch_followup":
            with ctx.lock:
                ctx.followups_started += 1
            self._submit_task(ctx, RuntimeTask(
                tool=tool,
                target=target,
                reason=f"followup:{reason}",
                rate_limit_rps=rps,
                wordlist=self._wordlist_for_context(ctx, task.wordlist),
                depth=task.depth,
            ))
            return

        if action == "compare_roles":
            with ctx.lock:
                ctx.followups_started += 1
            self._submit_task(ctx, RuntimeTask(
                tool="role_compare",
                target=target,
                reason=f"role_compare:{reason}",
                rate_limit_rps=1,
                wordlist=task.wordlist,
                depth=task.depth,
            ))
            return

        if action == "api_validate":
            with ctx.lock:
                ctx.followups_started += 1
            self._submit_task(ctx, RuntimeTask(
                tool="api_validate",
                target=target,
                reason=f"api_validate:{reason}",
                rate_limit_rps=1,
                wordlist=task.wordlist,
                depth=task.depth,
            ))

    def _run_role_compare(self, ctx: ScanContext, task: RuntimeTask) -> None:
        if requests is None:
            self._record_event(ctx, {"type": "role_compare_unavailable", "reason": "requests unavailable", "target": task.target, "timestamp": datetime.utcnow().isoformat()})
            return
        if len(ctx.role_contexts) < 2:
            self._record_event(ctx, {"type": "role_compare_skipped", "reason": "At least two role_contexts are required", "target": task.target, "timestamp": datetime.utcnow().isoformat()})
            return
        if not ctx.policy.target_in_scope(task.target):
            return

        results = []
        for role in ctx.role_contexts:
            try:
                response = requests.get(
                    task.target,
                    headers=role.get("headers") or {},
                    cookies=role.get("cookies") or {},
                    timeout=12,
                    allow_redirects=False,
                )
                body = response.text or ""
                digest = hashlib.sha256(body[:20000].encode("utf-8", errors="ignore")).hexdigest()
                results.append({
                    "role": role.get("name"),
                    "status": response.status_code,
                    "length": len(body),
                    "body_sha256_prefix": digest[:16],
                    "content_type": response.headers.get("content-type"),
                    "location": response.headers.get("location"),
                })
                time.sleep(max(0.2, 1 / max(1, task.rate_limit_rps)))
            except Exception as exc:
                results.append({"role": role.get("name"), "error": str(exc)})

        event = {
            "type": "role_compare_result",
            "tool": "role_compare",
            "target": task.target,
            "url": task.target,
            "results": results,
            "risk_hint": self._role_compare_hint(task.target, results),
            "timestamp": datetime.utcnow().isoformat(),
        }
        self._enrich_event(event)
        self._record_event(ctx, event)
        if event.get("risk_hint") in {"possible_broken_access_control", "anonymous_high_value_access"}:
            self._save_evidence(ctx, "role_compare", task.target, event["risk_hint"], "high", event)

    def _role_compare_hint(self, target: str, results: List[Dict[str, Any]]) -> str:
        lower = target.lower()
        adminish = any(s in lower for s in ["admin", "/internal", "/manage", "/api/"])
        anonymous_2xx = any((r.get("role") or "").lower() in {"anon", "anonymous", "public"} and 200 <= int(r.get("status") or 0) < 300 for r in results)
        if adminish and anonymous_2xx:
            return "anonymous_high_value_access"
        status_groups = defaultdict(list)
        for r in results:
            if "status" in r:
                status_groups[int(r["status"])].append(r.get("role"))
        if adminish and any(200 <= s < 300 and len(roles) > 1 for s, roles in status_groups.items()):
            return "possible_broken_access_control"
        return "role_compare_evidence"

    def _run_api_validate(self, ctx: ScanContext, task: RuntimeTask) -> None:
        if requests is None:
            self._record_event(ctx, {"type": "api_validate_unavailable", "reason": "requests unavailable", "target": task.target, "timestamp": datetime.utcnow().isoformat()})
            return
        if not ctx.policy.target_in_scope(task.target):
            return

        probes = [
            ("HEAD", task.target),
            ("OPTIONS", task.target),
            ("GET", self._add_query_param(task.target, "hexstrike_probe", uuid.uuid4().hex[:8])),
        ]
        # If risky params already exist, duplicate with harmless alternate values using GET only.
        parsed = urlparse(task.target)
        for key, _ in parse_qsl(parsed.query, keep_blank_values=True)[:5]:
            if PARAM_RISK_RE.search(key):
                probes.append(("GET", self._replace_query_param(task.target, key, "hexstrike_invalid_probe")))

        results = []
        headers = {"X-HexStrike-Probe": "safe-api-validation"}
        for method, url in probes[:6]:
            try:
                response = requests.request(method, url, headers=headers, timeout=12, allow_redirects=False)
                text = response.text or ""
                results.append({
                    "method": method,
                    "url": url,
                    "status": response.status_code,
                    "length": len(text),
                    "content_type": response.headers.get("content-type"),
                    "server_error_hint": response.status_code >= 500 or "stack trace" in text.lower() or "traceback" in text.lower(),
                })
                time.sleep(max(0.2, 1 / max(1, task.rate_limit_rps)))
            except Exception as exc:
                results.append({"method": method, "url": url, "error": str(exc)})

        hint = "api_validation_evidence"
        if any(r.get("server_error_hint") for r in results):
            hint = "server_error"
        event = {
            "type": "api_validate_result",
            "tool": "api_validate",
            "target": task.target,
            "url": task.target,
            "results": results,
            "risk_hint": hint,
            "timestamp": datetime.utcnow().isoformat(),
        }
        self._enrich_event(event)
        self._record_event(ctx, event)
        if hint == "server_error":
            self._save_evidence(ctx, "api_validate", task.target, "Safe API probe triggered server error", "high", event)

    def _add_query_param(self, url: str, key: str, value: str) -> str:
        parsed = urlparse(url)
        q = parse_qsl(parsed.query, keep_blank_values=True)
        q.append((key, value))
        return urlunparse(parsed._replace(query=urlencode(q)))

    def _replace_query_param(self, url: str, key: str, value: str) -> str:
        parsed = urlparse(url)
        q = [(k, value if k == key else v) for k, v in parse_qsl(parsed.query, keep_blank_values=True)]
        return urlunparse(parsed._replace(query=urlencode(q)))

    def _wordlist_for_context(self, ctx: ScanContext, fallback: str) -> str:
        words = [w for w, _ in ctx.discovered_segments.most_common(100) if 2 <= len(w) <= 40]
        if len(words) < 10:
            return fallback
        path = self.data_dir / f"{ctx.run_id}_adaptive_wordlist.txt"
        try:
            path.write_text("\n".join(sorted(set(words))) + "\n", encoding="utf-8")
            return str(path)
        except Exception:
            return fallback

    def _record_event(self, ctx: ScanContext, event: Dict[str, Any]) -> None:
        with ctx.lock:
            ctx.events.append(event)
            status = event.get("status")
            risk_hint = event.get("risk_hint")
            if risk_hint == "server_error" or (isinstance(status, int) and status >= 500):
                ctx.server_error_events += 1
                if ctx.server_error_events >= ctx.policy.max_5xx_events:
                    ctx.stop_requested = True
                    event["stop_condition_triggered"] = "max_5xx_events"
        self._append_jsonl(self.data_dir / f"{ctx.run_id}_events.jsonl", event)

    def _record_decision(self, ctx: ScanContext, decision: Dict[str, Any]) -> None:
        with ctx.lock:
            ctx.decisions.append(decision)
        self._append_jsonl(self.data_dir / f"{ctx.run_id}_decisions.jsonl", decision)

    def _save_evidence(self, ctx: ScanContext, tool: str, target: str, reason: str, priority: str, source: Dict[str, Any]) -> None:
        finding = {
            "type": "runtime_evidence",
            "tool": tool,
            "target": target,
            "reason": reason,
            "priority": priority,
            "source_summary": self._safe_evidence_summary(source),
            "timestamp": datetime.utcnow().isoformat(),
        }
        with ctx.lock:
            ctx.findings.append(finding)
        self._append_jsonl(self.data_dir / f"{ctx.run_id}_findings.jsonl", finding)

    def _safe_evidence_summary(self, source: Dict[str, Any]) -> Dict[str, Any]:
        # Avoid writing large/sensitive response bodies. Keep structural evidence only.
        allowed = {"type", "tool", "target", "url", "status", "risk_hint", "risk_score", "endpoint_kind", "evidence_tags", "template_id", "severity", "results", "reason", "priority"}
        return {k: v for k, v in source.items() if k in allowed}

    def _safe_command_preview(self, command: List[str]) -> str:
        redacted = []
        for item in command:
            if any(s in item.lower() for s in ["authorization", "bearer", "cookie", "token", "password"]):
                redacted.append("[REDACTED]")
            else:
                redacted.append(item)
        return " ".join(redacted[:12])

    def _terminate(self, process: subprocess.Popen) -> None:
        try:
            if process.poll() is not None:
                return
            if os.name != "nt":
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            else:
                process.terminate()
        except Exception:
            try:
                process.kill()
            except Exception:
                pass

    def _append_jsonl(self, path: Path, record: Dict[str, Any]) -> None:
        try:
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, default=str) + "\n")
        except Exception:
            pass

    def _summary(self, ctx: ScanContext) -> Dict[str, Any]:
        interesting: List[str] = []
        for event in ctx.events:
            if event.get("risk_hint") in {
                "admin_path", "api_path", "upload_endpoint", "graphql_endpoint", "server_error",
                "sensitive_hint", "tool_finding", "idor_candidate", "risky_parameter",
                "possible_broken_access_control", "anonymous_high_value_access"
            }:
                url = event.get("url")
                if url and url not in interesting:
                    interesting.append(url)

        return {
            "success": True,
            "status": "completed_or_timeboxed",
            "mode": "local_llm_realtime_tool_modulation_power_safe",
            "run_id": ctx.run_id,
            "target": ctx.target,
            "profile": ctx.profile,
            "local_llm_required": ctx.policy.require_local_llm,
            "local_llm": self.llm.health(),
            "jobs_started": ctx.jobs_started,
            "followups_started": ctx.followups_started,
            "stopped_jobs": ctx.stopped_jobs,
            "server_error_events": ctx.server_error_events,
            "events_seen": len(ctx.events),
            "decisions_made": len(ctx.decisions),
            "evidence_saved": len(ctx.findings),
            "risk_counter": dict(ctx.risk_counter.most_common()),
            "endpoint_kind_counter": dict(ctx.endpoint_kind_counter.most_common()),
            "top_discovered_segments": [w for w, _ in ctx.discovered_segments.most_common(25)],
            "top_discovered_params": [w for w, _ in ctx.discovered_params.most_common(25)],
            "interesting_targets": interesting[:50],
            "events_file": str(self.data_dir / f"{ctx.run_id}_events.jsonl"),
            "decisions_file": str(self.data_dir / f"{ctx.run_id}_decisions.jsonl"),
            "findings_file": str(self.data_dir / f"{ctx.run_id}_findings.jsonl"),
            "adaptive_wordlist_file": str(self.data_dir / f"{ctx.run_id}_adaptive_wordlist.txt"),
            "recommended_next_hexstrike_action": "Review runtime evidence, then run authenticated role comparison/API validation on the interesting targets using supplied test role contexts.",
            "blocked_capabilities": sorted(AuthorizedPentestPlanner.BLOCKED_CAPABILITIES),
            "started_at": datetime.fromtimestamp(ctx.started_at).isoformat(),
            "finished_at": datetime.utcnow().isoformat(),
        }


class AuthorizedPentestPlanner:
    """Builds a safe, authorised pentest plan without executing destructive actions."""

    BLOCKED_CAPABILITIES = {
        "credential_attacks",
        "brute_force",
        "stealth",
        "waf_bypass",
        "destructive_testing",
        "exploit_chain_execution",
        "data_exfiltration",
        "persistence",
        "lateral_movement",
    }

    SAFE_PHASES = [
        {
            "phase": "0_scope_and_safety",
            "goal": "Confirm owned/in-scope hosts, blocked production/destructive paths, rate limits, local LLM status, and test accounts.",
            "tools": [],
            "runtime_modulation": "Policy guard blocks out-of-scope targets and unsafe paths before any tool starts.",
        },
        {
            "phase": "1_attack_surface_discovery",
            "goal": "Discover pages, API paths, technologies, redirects, parameters, high-value areas, and app-specific wordlist terms.",
            "tools": ["katana", "httpx", "ffuf", "whatweb", "arjun"],
            "runtime_modulation": "Local LLM watches discovered URLs and redirects follow-up testing toward APIs, admin paths, upload endpoints, and GraphQL.",
        },
        {
            "phase": "2_misconfiguration_and_known_issue_checks",
            "goal": "Run selected non-destructive checks for known exposures and configuration issues.",
            "tools": ["nuclei", "zap", "testssl", "sslscan"],
            "runtime_modulation": "Local LLM narrows template use based on detected technology and stops noisy runs on error spikes.",
        },
        {
            "phase": "3_authenticated_access_control",
            "goal": "Use supplied test auth contexts to compare roles and detect IDOR/broken access control.",
            "tools": ["role_compare", "zap", "httpx"],
            "runtime_modulation": "If userId/accountId/orderId/admin endpoints appear, local LLM launches role-comparison checks using test auth headers/cookies only.",
        },
        {
            "phase": "4_api_validation_and_business_logic",
            "goal": "Test GET-safe boundary/unknown-parameter behaviour and server errors without destructive state changes.",
            "tools": ["api_validate", "arjun", "zap"],
            "runtime_modulation": "Local LLM prioritises parameters such as id, accountId, status, role, redirect, file, and callback.",
        },
        {
            "phase": "5_input_handling_and_client_side_findings",
            "goal": "Safely validate reflected input, headers, file-upload controls, and token/session design.",
            "tools": ["dalfox", "zap"],
            "runtime_modulation": "Local LLM sends only discovered input points to bounded validation and saves replayable evidence.",
        },
        {
            "phase": "6_risk_chain_mapping_not_execution",
            "goal": "Correlate confirmed findings into likely business-impact paths without automatically exploiting or chaining them.",
            "tools": [],
            "runtime_modulation": "Local LLM groups evidence into risk paths and recommends manual validation steps.",
        },
        {
            "phase": "7_reporting_and_retest",
            "goal": "Produce reproducible evidence, severity, remediation, and safe retest steps.",
            "tools": [],
            "runtime_modulation": "Evidence files from live modulation are summarised for HexStrike reporting.",
        },
    ]

    def __init__(self, llm: LocalLLMDecisionClient) -> None:
        self.llm = llm

    def build_plan(self, target: str, profile: str = "owned_web_full", options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        options = options or {}
        policy = RuntimePolicy.from_request(target, options)
        if not policy.target_in_scope(target):
            return {
                "success": False,
                "status": "blocked",
                "reason": "Target is outside approved scope for authorised pentest planning.",
                "target": target,
                "allowed_hosts": sorted(policy.allowed_hosts),
            }

        plan = {
            "success": True,
            "mode": "authorized_safe_full_pentest_planning_power_safe",
            "target": target,
            "profile": profile,
            "allowed_hosts": sorted(policy.allowed_hosts),
            "blocked_hosts": sorted(policy.blocked_hosts),
            "blocked_paths": list(policy.blocked_path_prefixes),
            "allowed_tools": sorted(policy.allowed_tools),
            "blocked_capabilities": sorted(self.BLOCKED_CAPABILITIES),
            "phases": self.SAFE_PHASES,
            "recommended_first_runtime_call": {
                "endpoint": "/api/tools/modulated-web-scan",
                "profile": "web_power",
                "options": {
                    "allowed_hosts": sorted(policy.allowed_hosts),
                    "rate_limit_rps": min(policy.default_rps, policy.max_rps),
                    "max_jobs": policy.max_jobs,
                    "max_runtime_seconds": policy.max_runtime_seconds,
                    "require_local_llm": policy.require_local_llm,
                },
            },
            "notes": [
                "This plan is for websites you own or are explicitly authorised to test.",
                "Exploit-chain execution is replaced with non-destructive risk-chain mapping.",
                "Credential attacks/brute force are replaced with credential-policy, MFA, lockout, and session-control review.",
                "Stealth and WAF bypass are intentionally blocked; use transparent allow-listed staging tests instead.",
                "Use role_contexts with test auth headers/cookies to enable safe role comparison.",
            ],
        }

        enrichment = self._safe_llm_enrichment(plan)
        if enrichment:
            plan["local_llm_prioritisation"] = enrichment
        return plan

    def _safe_llm_enrichment(self, plan: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not self.llm.enabled:
            return None
        event = {
            "type": "planning_enrichment_request",
            "target": plan.get("target"),
            "risk_hint": "safe_full_pentest_plan",
            "allowed_tools": plan.get("allowed_tools"),
            "blocked_capabilities": plan.get("blocked_capabilities"),
            "instruction": "Prioritise safe phases only. Do not add exploit execution, credential attacks, stealth, WAF bypass, destructive testing, or bypass steps.",
        }
        decision = self.llm.decide(event, require_local_llm=False)
        return {"decision": decision, "policy": "advisory_only; blocked capabilities remain blocked"}


def build_authorized_pentest_plan(target: str, profile: str = "owned_web_full", options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    planner = AuthorizedPentestPlanner(runtime_modulator.llm)
    return planner.build_plan(target, profile, options)


runtime_modulator = HexStrikeRuntimeModulator()
